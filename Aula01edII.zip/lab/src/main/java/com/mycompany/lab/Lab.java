/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab;

/**
 *
 * @author GeoDantas
 */
public class Lab {

    static char[][] lab = {
        {'#', '#', '#', '#', '#'},
        {'#', 'E', '.', '.', '#'},
        {'#', '#', '#', '.', '#'},
        {'#', '.', '.', 'S', '#'},
        {'#', '#', '#', '#', '#'}
    };

    static boolean[][] visitados = new boolean[5][5];

    public static boolean resolver(int linha, int col) {
        if (linha < 0 || linha >= 5 || col < 0 || col >= 5) {
            return false;
        }

        if (lab[linha][col] == '#' || visitados[linha][col]) {
            return false;
        }

        if (lab[linha][col] == 'S') {
            return true;
        }

        visitados[linha][col] = true;

        if (resolver(linha - 1, col)) {
            if (lab[linha][col] != 'E') lab[linha][col] = '*';
            return true;
        }
        if (resolver(linha + 1, col)) {
            if (lab[linha][col] != 'E') lab[linha][col] = '*';
            return true;
        }
        if (resolver(linha, col - 1)) {
            if (lab[linha][col] != 'E') lab[linha][col] = '*';
            return true;
        }
        if (resolver(linha, col + 1)) {
            if (lab[linha][col] != 'E') lab[linha][col] = '*';
            return true;
        }

        return false;
    }

    public static void imprimirLab() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (j > 0) System.out.print(" ");
                System.out.print(lab[i][j]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        System.out.println("labirinto original:");
        imprimirLab();
        System.out.println();

        boolean achou = resolver(1, 1);

        if (achou) {
            System.out.println("caminho encontrado:");
            imprimirLab();
        } else {
            System.out.println("labirinto sem saida.");
        }
    }
}