/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.imp;

/**
 *
 * @author GeoDantas
 */
import java.util.Scanner;

class TrabalhoPrint {
    int idAluno;
    String nomeArquivo;
    int numPag;

    public TrabalhoPrint(int idAluno, String nomeArquivo, int numPag) {
        this.idAluno = idAluno;
        this.nomeArquivo = nomeArquivo;
        this.numPag = numPag;
    }
}

class FilaImp {
    TrabalhoPrint[] fila = new TrabalhoPrint[100];
    int inicio = 0;
    int fim = 0;

    public void enqueue(TrabalhoPrint t) {
        fila[fim] = t;
        fim++;
        System.out.println("trabalho '" + t.nomeArquivo + "' adicionado na fila.");
    }

    public void dequeue() {
        if (isEmpty()) {
            System.out.println("fila vazia");
            return;
        }
        TrabalhoPrint t = fila[inicio];
        inicio++;
        System.out.println("imprimindo: " + t.nomeArquivo + " aluno: " + t.idAluno + " paginas: " + t.numPag);
    }

    public boolean isEmpty() {
        return inicio == fim;
    }

    public void exibirFila() {
        if (isEmpty()) {
            System.out.println("fila vazia.");
            return;
        }
        System.out.println("\nfila de Impressao");
        for (int i = inicio; i < fim; i++) {
            TrabalhoPrint t = fila[i];
            System.out.println((i - inicio + 1) + ". aluno: " + t.idAluno + " arquivo: " + t.nomeArquivo + " paginas: " + t.numPag);
        }
        System.out.println("-------------------------\n");
    }
}

public class Imp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FilaImp fila = new FilaImp();

        while (true) {
            System.out.println("\n1 adicionar trabalho");
            System.out.println("2 imprimir proximo");
            System.out.println("3 ver fila");
            System.out.println("4 sair");
            System.out.print("escolha: ");
            String op = sc.nextLine();

            if (op.equals("1")) {
                System.out.print("id do aluno: ");
                int id = Integer.parseInt(sc.nextLine());
                System.out.print("nome do arquivo: ");
                String nome = sc.nextLine();
                System.out.print("numero de paginas: ");
                int paginas = Integer.parseInt(sc.nextLine());
                fila.enqueue(new TrabalhoPrint(id, nome, paginas));
            } else if (op.equals("2")) {
                fila.dequeue();
            } else if (op.equals("3")) {
                fila.exibirFila();
            } else if (op.equals("4")) {
                break;
            } else {
                System.out.println("invalida.");
            }
        }

        sc.close();
    }
}