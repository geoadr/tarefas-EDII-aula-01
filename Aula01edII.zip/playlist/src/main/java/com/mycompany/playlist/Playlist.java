/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.playlist;

/**
 *
 * @author GeoDantas
 */
import java.util.Scanner;

class Music {
    String titulo;
    String artista;
    Music proxima;

    public Music(String titulo, String artista) {
        this.titulo = titulo;
        this.artista = artista;
        this.proxima = null;
    }
}

class GerenciadorPlaylist {
    Music cabeca = null;

    public void adicionarMusic(String titulo, String artista) {
        Music nova = new Music(titulo, artista);
        if (cabeca == null) {
            cabeca = nova;
        } else {
            Music atual = cabeca;
            while (atual.proxima != null) {
                atual = atual.proxima;
            }
            atual.proxima = nova;
        }
        System.out.println("musica '" + titulo + "' adicionada com sucesso!");
    }

    public void removerMusic(String titulo) {
        
        if (cabeca == null) {
            System.out.println("Playlist vazia.");
            return;
        }

        if (cabeca.titulo.equals(titulo)) {
            cabeca = cabeca.proxima;
            System.out.println("musica '" + titulo + "' removida.");
            return;
        }

        Music atual = cabeca;
        while (atual.proxima != null) {
            if (atual.proxima.titulo.equals(titulo)) {
                atual.proxima = atual.proxima.proxima;
                System.out.println("musica '" + titulo + "' removida.");
                return;
            }
            atual = atual.proxima;
        }

        System.out.println("musica '" + titulo + "' nao encontrada.");
    }

    public void buscarMusic(String titulo) {
        Music atual = cabeca;
        while (atual != null) {
            if (atual.titulo.equals(titulo)) {
                System.out.println("musica encontrada: '" + atual.titulo + "' - artista: " + atual.artista);
                return;
            }
            atual = atual.proxima;
        }
        System.out.println("musica '" + titulo + "' nao encontrada na playlist.");
    }

    public void listarMusics() {
        if (cabeca == null) {
            System.out.println("a playlist esta vazia.");
            return;
        }
        System.out.println("\n--- playlist ---");
        Music atual = cabeca;
        int i = 1;
        while (atual != null) {
            System.out.println(i + ". " + atual.titulo + " - " + atual.artista);
            atual = atual.proxima;
            i++;
        }
        System.out.println("----------------\n");
    }
}

public class Playlist {
    
    static void exibirMenu() {
        System.out.println("\n1 adicionar musica");
        System.out.println("2 remover musica");
        System.out.println("3 buscar musica");
        System.out.println("4 listar musicas");
        System.out.println("5 sair");
        System.out.print("escolha: ");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        GerenciadorPlaylist playlist = new GerenciadorPlaylist();

        while (true) {
            exibirMenu();
            String op = sc.nextLine();

            if (op.equals("1")) {
                System.out.print("titulo da musica: ");
                String titulo = sc.nextLine();
                System.out.print("artista: ");
                String artista = sc.nextLine();
                playlist.adicionarMusic(titulo, artista);
            } else if (op.equals("2")) {
                System.out.print("titulo da musica para remover: ");
                String titulo = sc.nextLine();
                playlist.removerMusic(titulo);
            } else if (op.equals("3")) {
                System.out.print("titulo da musica para buscar: ");
                String titulo = sc.nextLine();
                playlist.buscarMusic(titulo);
            } else if (op.equals("4")) {
                playlist.listarMusics();
            } else if (op.equals("5")) {
                System.out.println("saindo");
                break;
            } else {
                System.out.println("invalida.");
            }
        }

        sc.close();
    }
}