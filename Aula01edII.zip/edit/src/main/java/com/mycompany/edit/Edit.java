/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.edit;

/**
 *
 * @author GeoDantas
 */

import java.util.Scanner;

class Pilha {
    String[] tipos = new String[100];
    String[] dados = new String[100];
    int topo = -1;

    public void push(String tipo, String dado) {
        topo++;
        tipos[topo] = tipo;
        dados[topo] = dado;
    }

    public String getTipo() {
        return tipos[topo];
    }

    public String getDado() {
        return dados[topo];
    }

    public void pop() {
        topo--;
    }

    public boolean isEmpty() {
        return topo == -1;
    }
}

public class Edit {
    static String textoAtual = "";
    static Pilha pilhaDesfazer = new Pilha();
    static Pilha pilhaRefazer = new Pilha();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("comandos: inserir <texto>, remover <n>, desfazer, refazer, imprimir, sair");

        while (true) {
            System.out.print("> ");
            String cmd = sc.nextLine().trim();

            if (cmd.startsWith("inserir ")) {
                String trecho = cmd.substring(8);
                pilhaDesfazer.push("inserir", trecho);
                pilhaRefazer = new Pilha();
                textoAtual += trecho;

            } else if (cmd.startsWith("remover ")) {
                int n = Integer.parseInt(cmd.substring(8).trim());
                String removido = textoAtual.substring(textoAtual.length() - n);
                pilhaDesfazer.push("remover", removido);
                pilhaRefazer = new Pilha();
                textoAtual = textoAtual.substring(0, textoAtual.length() - n);

            } else if (cmd.equals("desfazer")) {
                if (pilhaDesfazer.isEmpty()) {
                    System.out.println("nada para desfazer.");
                } else {
                    String tipo = pilhaDesfazer.getTipo();
                    String dado = pilhaDesfazer.getDado();
                    pilhaRefazer.push(tipo, dado);
                    pilhaDesfazer.pop();
                    if (tipo.equals("inserir")) {
                        textoAtual = textoAtual.substring(0, textoAtual.length() - dado.length());
                    } else {
                        textoAtual += dado;
                    }
                }

            } else if (cmd.equals("refazer")) {
                if (pilhaRefazer.isEmpty()) {
                    System.out.println("nada para refazer.");
                } else {
                    String tipo = pilhaRefazer.getTipo();
                    String dado = pilhaRefazer.getDado();
                    pilhaDesfazer.push(tipo, dado);
                    pilhaRefazer.pop();
                    if (tipo.equals("inserir")) {
                        textoAtual += dado;
                    } else {
                        textoAtual = textoAtual.substring(0, textoAtual.length() - dado.length());
                    }
                }

            } else if (cmd.equals("imprimir")) {
                System.out.println(">> " + textoAtual);

            } else if (cmd.equalsIgnoreCase("sair")) {
                break;

            } else {
                System.out.println("invalido.");
            }
        }

        sc.close();
    }
}